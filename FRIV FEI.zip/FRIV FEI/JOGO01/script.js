const canvas = document.getElementById('labirinto');
const ctx = canvas.getContext('2d');

const player = { x: 20, y: 20, size: 20 };
const exit = { x: 460, y: 460, size: 20 };

const walls = [
  { x: 0, y: 100, w: 400, h: 20 },
  { x: 100, y: 200, w: 400, h: 20 },
  { x: 0, y: 300, w: 400, h: 20 },
  { x: 100, y: 400, w: 400, h: 20 },
];

function draw() {
  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, 500, 500);

  ctx.fillStyle = "#ff6600";
  walls.forEach(w => ctx.fillRect(w.x, w.y, w.w, w.h));

  ctx.fillStyle = "#00ff99";
  ctx.fillRect(exit.x, exit.y, exit.size, exit.size);

  ctx.fillStyle = "#fff";
  ctx.fillRect(player.x, player.y, player.size, player.size);
}

function checkCollision(x, y) {
  return walls.some(w => 
    x < w.x + w.w && x + player.size > w.x && 
    y < w.y + w.h && y + player.size > w.y
  );
}

document.addEventListener('keydown', e => {
  let newX = player.x, newY = player.y;
  if (e.key === 'ArrowUp') newY -= 20;
  if (e.key === 'ArrowDown') newY += 20;
  if (e.key === 'ArrowLeft') newX -= 20;
  if (e.key === 'ArrowRight') newX += 20;

  if (!checkCollision(newX, newY)) {
    player.x = newX;
    player.y = newY;
  }

  if (player.x === exit.x && player.y === exit.y) {
    alert("🎉 Você venceu!");
    player.x = 20;
    player.y = 20;
  }

  draw();
});

draw();
