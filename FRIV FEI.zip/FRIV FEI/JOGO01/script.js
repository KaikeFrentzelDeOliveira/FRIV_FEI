// script.js
window.addEventListener('DOMContentLoaded', () => {
  const canvas = document.getElementById('labirinto');
  const ctx = canvas.getContext('2d');

  const TILE = 20;
  const SIZE = 500;

  // jogador, saída e paredes
  const player = { x: 20, y: 20, size: TILE };
  const exit =   { x: 460, y: 460, size: TILE };

  const walls = [
    { x: 0,   y: 100, w: 400, h: 20 },
    { x: 100, y: 200, w: 400, h: 20 },
    { x: 0,   y: 300, w: 400, h: 20 },
    { x: 100, y: 400, w: 400, h: 20 },
  ];

  // ======== Desenhar ========
  function draw() {
    // fundo
    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, SIZE, SIZE);

    // paredes (azul)
    ctx.fillStyle = "#2196f3";
    walls.forEach(w => ctx.fillRect(w.x, w.y, w.w, w.h));

    // saída (azul neon)
    ctx.fillStyle = "#00e5ff";
    ctx.fillRect(exit.x, exit.y, exit.size, exit.size);

    // jogador (branco)
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(player.x, player.y, player.size, player.size);
  }

  // ======== Colisões ========
  function checkCollision(x, y) {
    if (x < 0 || y < 0 || x + player.size > SIZE || y + player.size > SIZE)
      return true;
    return walls.some(w =>
      x < w.x + w.w && x + player.size > w.x &&
      y < w.y + w.h && y + player.size > w.y
    );
  }

  // ======== Movimentação ========
  document.addEventListener('keydown', e => {
    const keys = ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'];
    if (!keys.includes(e.key)) return;

    e.preventDefault(); // evita scroll da página

    let newX = player.x;
    let newY = player.y;

    if (e.key === 'ArrowUp') newY -= TILE;
    if (e.key === 'ArrowDown') newY += TILE;
    if (e.key === 'ArrowLeft') newX -= TILE;
    if (e.key === 'ArrowRight') newX += TILE;

    if (!checkCollision(newX, newY)) {
      player.x = newX;
      player.y = newY;
    }

    // Checa vitória
    if (player.x === exit.x && player.y === exit.y) {
      setTimeout(() => alert("💙 Você venceu!"), 10);
      player.x = 20;
      player.y = 20;
    }

    draw();
  });

  // Desenha o labirinto ao iniciar
  draw();
});
