const canvas = document.getElementById('memoria');
const ctx = canvas.getContext('2d');

const cores = ['#ff6600', '#00ff99', '#ff0099', '#0099ff', '#ffff00', '#ff3300'];
let cartas = [];
let selecionadas = [];

function iniciarJogo() {
  cartas = [...cores, ...cores]
    .sort(() => Math.random() - 0.5)
    .map((cor, i) => ({ cor, revelada: false, x: (i % 4) * 120 + 20, y: Math.floor(i / 4) * 120 + 20 }));

  desenhar();
}

function desenhar() {
  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, 500, 500);

  cartas.forEach(c => {
    ctx.fillStyle = c.revelada ? c.cor : "#222";
    ctx.fillRect(c.x, c.y, 100, 100);
  });
}

canvas.addEventListener('click', e => {
  const rect = canvas.getBoundingClientRect();
  const x = e.clientX - rect.left;
  const y = e.clientY - rect.top;

  const carta = cartas.find(c => x > c.x && x < c.x + 100 && y > c.y && y < c.y + 100);
  if (carta && !carta.revelada && selecionadas.length < 2) {
    carta.revelada = true;
    selecionadas.push(carta);
    desenhar();

    if (selecionadas.length === 2) {
      setTimeout(() => {
        if (selecionadas[0].cor !== selecionadas[1].cor) {
          selecionadas.forEach(c => c.revelada = false);
        }
        selecionadas = [];
        desenhar();
      }, 700);
    }
  }
});

iniciarJogo();
