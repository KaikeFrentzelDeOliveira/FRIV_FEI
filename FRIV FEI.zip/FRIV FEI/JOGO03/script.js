// === Configurações básicas ===
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const faseTexto = document.getElementById("faseTexto");
const vitoriaImg = document.getElementById("vitoria");

// === Carrega sprites ===
const sprites = {
  parado: new Image(),
  correndo1: new Image(),
  correndo2: new Image(),
  pulo: new Image()
};
sprites.parado.src = "sprites/Parado.png";
sprites.correndo1.src = "sprites/Correndo01.png";
sprites.correndo2.src = "sprites/Correndo02.png";
sprites.pulo.src = "sprites/Pulo.png";

// === Variáveis do jogador ===
let player = {
  x: 50,
  y: 400,
  largura: 50,
  altura: 70,
  velX: 0,
  velY: 0,
  noChao: false,
  direcao: 1,
  spriteAtual: sprites.parado,
  animFrame: 0
};

// === Gravidade e física ===
const gravidade = 0.8;
const forcaPulo = -14;
const velocidade = 5;

// === Controle ===
let teclas = {};

// === Fases ===
let faseAtual = 1;

const fases = [
  {
    plataformas: [
      { x: 0, y: 470, w: 800, h: 30 },
      { x: 150, y: 400, w: 120, h: 20 },
      { x: 350, y: 350, w: 120, h: 20 },
      { x: 550, y: 300, w: 120, h: 20 }
    ],
    porta: { x: 700, y: 240, w: 40, h: 60 }
  },
  {
    plataformas: [
      { x: 0, y: 470, w: 800, h: 30 },
      { x: 200, y: 420, w: 100, h: 20 },
      { x: 400, y: 360, w: 100, h: 20 },
      { x: 600, y: 300, w: 100, h: 20 }
    ],
    porta: { x: 720, y: 240, w: 40, h: 60 }
  },
  {
    plataformas: [
      { x: 0, y: 470, w: 800, h: 30 },
      { x: 150, y: 420, w: 100, h: 20 },
      { x: 350, y: 380, w: 100, h: 20 },
      { x: 550, y: 330, w: 100, h: 20 }
    ],
    porta: { x: 700, y: 270, w: 40, h: 60 }
  }
];

// === Movimento do jogador ===
document.addEventListener("keydown", (e) => (teclas[e.key] = true));
document.addEventListener("keyup", (e) => (teclas[e.key] = false));

// === Atualização do jogo ===
function atualizar() {
  const fase = fases[faseAtual - 1];

  // Movimento horizontal
  if (teclas["ArrowRight"] || teclas["d"]) {
    player.velX = velocidade;
    player.direcao = 1;
    player.animFrame++;
    player.spriteAtual = player.animFrame % 20 < 10 ? sprites.correndo1 : sprites.correndo2;
  } else if (teclas["ArrowLeft"] || teclas["a"]) {
    player.velX = -velocidade;
    player.direcao = -1;
    player.animFrame++;
    player.spriteAtual = player.animFrame % 20 < 10 ? sprites.correndo1 : sprites.correndo2;
  } else {
    player.velX = 0;
    player.spriteAtual = sprites.parado;
  }

  // Pulo
  if ((teclas[" "] || teclas["ArrowUp"] || teclas["w"]) && player.noChao) {
    player.velY = forcaPulo;
    player.noChao = false;
    player.spriteAtual = sprites.pulo;
  }

  // Física
  player.velY += gravidade;
  player.x += player.velX;
  player.y += player.velY;

  // Limites da tela
  if (player.x < 0) player.x = 0;
  if (player.x + player.largura > canvas.width) player.x = canvas.width - player.largura;

  // Colisão com plataformas
  player.noChao = false;
  fase.plataformas.forEach((p) => {
    if (
      player.x < p.x + p.w &&
      player.x + player.largura > p.x &&
      player.y < p.y + p.h &&
      player.y + player.altura > p.y
    ) {
      if (player.velY > 0 && player.y + player.altura - player.velY <= p.y) {
        player.y = p.y - player.altura;
        player.velY = 0;
        player.noChao = true;
      }
    }
  });

  // Porta (chegada)
  const porta = fase.porta;
  if (
    player.x < porta.x + porta.w &&
    player.x + player.largura > porta.x &&
    player.y < porta.y + porta.h &&
    player.y + player.altura > porta.y
  ) {
    proximaFase();
  }

  // Se cair
  if (player.y > canvas.height) {
    faseAtual = 1;
    faseTexto.textContent = `Fase: ${faseAtual}`;
    resetarPlayer();
  }

  desenhar();
  requestAnimationFrame(atualizar);
}

// === Desenhar tudo ===
function desenhar() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Fundo gradiente
  const grad = ctx.createLinearGradient(0, 0, 0, canvas.height);
  grad.addColorStop(0, "#021a2e");
  grad.addColorStop(1, "#000");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Plataformas
  const fase = fases[faseAtual - 1];
  ctx.fillStyle = "#00ffff";
  fase.plataformas.forEach((p) => {
    ctx.fillRect(p.x, p.y, p.w, p.h);
  });

  // Porta
  const porta = fase.porta;
  ctx.fillStyle = "gold";
  ctx.fillRect(porta.x, porta.y, porta.w, porta.h);

  // Jogador
  ctx.save();
  if (player.direcao === -1) {
    ctx.scale(-1, 1);
    ctx.drawImage(player.spriteAtual, -player.x - player.largura, player.y, player.largura, player.altura);
  } else {
    ctx.drawImage(player.spriteAtual, player.x, player.y, player.largura, player.altura);
  }
  ctx.restore();
}

// === Trocar de fase ===
function proximaFase() {
  if (faseAtual < fases.length) {
    faseAtual++;
    faseTexto.textContent = `Fase: ${faseAtual}`;
    resetarPlayer();
  } else {
    // Vitória 🎉
    vitoriaImg.src = "coloque-aqui-o-caminho-da-sua-imagem.png";
    vitoriaImg.style.display = "block";
  }
}

// === Resetar jogador ===
function resetarPlayer() {
  player.x = 50;
  player.y = 400;
  player.velY = 0;
}

// === Iniciar jogo ===
resetarPlayer();
atualizar();
