// Seleciona o canvas e define o contexto 2D
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// Seleciona os elementos de pontuação e botão de reiniciar
const scoreElement = document.getElementById('score');
const restartButton = document.getElementById('restartButton');

// Define o tamanho de cada célula da grade (20x20 pixels)
const gridSize = 20;

// Variáveis principais do jogo
let snake = []; // array que armazena as posições da cobra
let food = {}; // objeto que armazena a posição da comida
let dx = 0, dy = 1; // direção inicial (1 para direita, 0 para parado verticalmente)
let score = 0; // pontuação inicial
let gameInterval; // controla o loop do jogo
let isGameOver = false; // indica se o jogo terminou

// Gera uma nova comida em posição aleatória
function generateFood() {
  food = {
    x: Math.floor(Math.random() * (canvas.width / gridSize)),
    y: Math.floor(Math.random() * (canvas.height / gridSize)),
  };
}

// Função que desenha todos os elementos do jogo
function draw() {
  // Limpa o canvas
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Desenha a comida (vermelha)
  ctx.fillStyle = 'red';
  ctx.fillRect(food.x * gridSize, food.y * gridSize, gridSize, gridSize);

  // Desenha a cobra (verde)
  ctx.fillStyle = 'lime';
  snake.forEach(segment => {
    ctx.fillRect(segment.x * gridSize, segment.y * gridSize, gridSize, gridSize);
  });
}

// Atualiza o estado do jogo (movimento, colisões e pontuação)
function update() {
  // Se o jogo acabou, para a execução
  if (isGameOver) return;

  // Cria nova cabeça da cobra com base na direção atual
  const head = { x: snake[0].x + dx, y: snake[0].y + dy };

  // Adiciona a nova cabeça no início do array da cobra
  snake.unshift(head);

  // Verifica se comeu a comida
  if (head.x === food.x && head.y === food.y) {
    score++; // aumenta pontuação
    scoreElement.textContent = `Pontos: ${score}`; // atualiza na tela
    generateFood(); // gera nova comida
  } else {
    // Se não comeu, remove o último segmento (movimento normal)
    snake.pop();
  }

  // Verifica colisões (com parede ou com o próprio corpo)
  if (checkCollision()) {
    endGame();
  }
}

// Verifica se houve colisão
function checkCollision() {
  const head = snake[0];

  // Colisão com as paredes do canvas
  const hitWall =
    head.x < 0 || head.x >= canvas.width / gridSize ||
    head.y < 0 || head.y >= canvas.height / gridSize;

  // Colisão com o próprio corpo
  const hitSelf = snake.slice(1).some(segment => segment.x === head.x && segment.y === head.y);

  // Retorna true se houver qualquer tipo de colisão
  return hitWall || hitSelf;
}

// Finaliza o jogo
function endGame() {
  isGameOver = true; // marca que acabou
  clearInterval(gameInterval); // para o loop
  alert(`Fim de jogo! Sua pontuação foi de ${score}`); // mostra pontuação final
}

// Função que faz o jogo rodar continuamente
function gameLoop() {
  update(); // atualiza lógica
  draw(); // redesenha na tela
}

// Inicia o jogo do zero
function startGame() {
  snake = [{ x: 10, y: 10 }]; // posição inicial da cobra
  dx = 1; dy = 0; // direção inicial (para direita)
  score = 0; // zera pontuação
  isGameOver = false; // reinicia estado
  scoreElement.textContent = 'Pontos: 0'; // mostra pontuação inicial

  // Se já havia um loop ativo, limpa ele
  if (gameInterval) clearInterval(gameInterval);

  generateFood(); // cria a primeira comida
  gameInterval = setInterval(gameLoop, 100); // inicia o loop (a cada 100ms)
}

// Detecta as teclas pressionadas e muda a direção da cobra
document.addEventListener('keydown', e => {
  switch (e.key) {
    case 'ArrowUp':
      if (dy === 0) { dx = 0; dy = -1; } // muda pra cima
      break;
    case 'ArrowDown':
      if (dy === 0) { dx = 0; dy = 1; } // muda pra baixo
      break;
    case 'ArrowLeft':
      if (dx === 0) { dx = -1; dy = 0; } // muda pra esquerda
      break;
    case 'ArrowRight':
      if (dx === 0) { dx = 1; dy = 0; } // muda pra direita
      break;
  }
});

// Botão de reiniciar o jogo
restartButton.addEventListener('click', startGame);

// Começa o jogo automaticamente quando a página carrega
startGame();
